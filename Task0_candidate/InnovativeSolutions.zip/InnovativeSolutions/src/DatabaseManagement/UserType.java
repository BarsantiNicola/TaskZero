package DatabaseManagement;

public enum UserType{
    ADMINISTRATOR,
    HEAD_DEPARTMENT,
    CUSTOMER,
    NOUSER
};